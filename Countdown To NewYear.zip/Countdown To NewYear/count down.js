
const countdown = () => {
    const countdown = new Date("January 1, 2022 00:00:00").getTime();
    const now = new Date().getTime();
    const gap = countdown - now;

    const seconds = 1000;
    const minutes = seconds * 60;
    const hours = minutes * 60;
    const day = hours * 24;

     const textDay = Math.floor(gap/day);
     const textHour = Math.floor((gap % day)/ hours);
     const textMinutes = Math.floor((gap % hours)/ minutes);
     const textSeconds = Math.floor((gap % minutes)/ seconds);

     document.getElementById("days").innerHTML = textDay;
     document.getElementById("hrs").innerHTML = textHour;
     document.getElementById("mins").innerHTML = textMinutes;
     document.getElementById("sec").innerHTML = textSeconds;

}
setInterval(countdown,1000)